# structured project example

While the snake example is a working game, it serves more to show basic capabilities. if your game is more complex, than a simple snake, you will want to structure your game better. mostly into scenes and more files. This demo shows a project with multiple scenes in more files.
