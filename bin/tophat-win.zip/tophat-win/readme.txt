How to use:
	init.bat - creates a new tophat project
	package.bat - package a project for release

Additional info can be found here: https://github.com/marekmaskarinec/tophat
Discord server: https://discord.gg/PcT7cn59h9
