# snake example

This is an example of snake implementation in tophat. Don't switch screens the same way i do it. This [example](https://github.com/marekmaskarinec/tophat/tree/main/examples/structured-project) shows a better way of doing it.

