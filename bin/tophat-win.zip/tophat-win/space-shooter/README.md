# space shooter

A complete game as an example. File structure is in game.um. Game is inspired by [this](https://ztiromoritz.github.io/pico-8-shooter/) pico-8 example.
