# UmBox + Tophat

You have successfully initialized an UmBox box from the tophat template.
For more information about tophat, visit [tophat2d.dev](https://tophat2d.dev).
